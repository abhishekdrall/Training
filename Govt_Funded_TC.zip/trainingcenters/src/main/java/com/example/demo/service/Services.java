package com.example.demo.service;

import java.util.List;

import com.example.demo.entities.Center;

public interface Services {
	
	public List<Center> getCenter();
	
	public Center addCenter(Center center);
}
