package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.CoursesOffered;

public interface CoursesOfferedDao extends JpaRepository< CoursesOffered , String>{

}
