package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.CenterDao;
import com.example.demo.entities.Center;

@Service
public class CenterService implements Services {

	@Autowired
	private CenterDao centerDao;
	
	
	@Override
	public List<Center> getCenter() {		
		return centerDao.findAll();
	}

	@Override
	public Center addCenter(Center center) {
		centerDao.save(center);
		return center;
	}

}
