package com.example.demo.entities;

public class Address {
	private	String detailAddress;	//	 Detailed Address
	private	String city;			//	 City
	private	String state;			//	 State
	private	String pincode;			//	 Pincode
	public String getDetailAddress() {
	return detailAddress;
	}
	public void setDetailAddress(String detailAddress) {
		this.detailAddress = detailAddress;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	public Address(String detailAddress, String city, String state, String pincode) {
		super();
		this.detailAddress = detailAddress;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}

	public Address() {
		super();
	}


}
