package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Center;
import com.example.demo.service.Services;

@RestController
@RequestMapping("/api/")
public class MyController { 
	
	@Autowired
	private Services services; 
	
	//Welcome page
	@GetMapping("home")
	public String home(){
		return "Welcome to govt funded training center details.";
	}
	
	//Get list of all stored training 
	@GetMapping(path="centerdetails",consumes="application/json")
	public List<Center> getCenter(){
		return this.services.getCenter();
	}
	
	// New Entry
	@PostMapping(path="addcenter",consumes="application/json")
	public ResponseEntity<Center> addCenter(@Valid @RequestBody Center center){
		Center savedCenter=services.addCenter(center);
		return new ResponseEntity<Center>(savedCenter, HttpStatus.CREATED);
	}
	
	
}
