package com.example.demo.entities;

import java.io.IOException;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Converter
public class AddressToJsonCoverter implements AttributeConverter<Address, String>{

	ObjectMapper objectMapper = new ObjectMapper();
	
	@Override
	public String convertToDatabaseColumn(Address address)  {
		{
			String json = "";
		    try {
		    	
		        json = objectMapper.writeValueAsString(address);
		    } catch (JsonProcessingException jpe) {
		        // Handle exception
		    }
		    return  json;
		}
	}

	@Override
	public Address convertToEntityAttribute(String addressAsJson) {
		{
			 Address address= null;
		        try {
		            address = objectMapper.readValue(addressAsJson, Address.class);
		        } catch (JsonParseException e) {
		            // HandleException
		        } catch (JsonMappingException e) {
		            // HandleException
		        } catch (IOException e) {
		            // HandleException
		        }
		        return address;    
		}
	}

}
